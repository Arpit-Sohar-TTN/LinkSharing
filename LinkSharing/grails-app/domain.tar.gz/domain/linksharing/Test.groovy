package linksharing

class Test {

    static constraints = {
    }
}
